Hey !

Voici la base d'un bot discord. Il est open-source.

Il te faudras les librairies "discord.js" et "fs" pour que le bot puisse fonctionner !
